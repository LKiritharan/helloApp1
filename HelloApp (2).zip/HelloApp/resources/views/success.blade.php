<!DOCTYPE html>
<html >
    <head>
       <title>La</title>
</head>
<body> 
<h1>You are successfully login to the System....</h1></br>
@if(isset(Auth::user()->email))
<strong> welcome {{Auth::user()->name}}</strong></br>
<strong> Your Email: {{Auth::user()->email}}</strong></br>
<a href="{{url('logout')}}" >Logout</a>
@else
<script>window.loation="/";</script>
@endif
</body>
    </body>
</html>
