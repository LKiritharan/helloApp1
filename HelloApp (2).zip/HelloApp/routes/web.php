<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\LoginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/success', function () {
    return view('success');
});
Route::get('/log', function () {
    return view('login');
});
Route::get('/wrong', function () {
    return view('wrong');
});
Route::get('/hello',[IndexController::class,'sayhello']);
Route::get('/login',[LoginController::class,'saylogin']);
Route::post('/login',[LoginController::class,'checkLogin']);
Route::get('/logout',[LoginController::class,'logout']);