<!DOCTYPE html>
<html >
    <head>
       <title>La</title>
</head>
<body> 
<h1>You are successfully login to the System....</h1></br>
<?php if(isset(Auth::user()->email)): ?>
<strong> welcome <?php echo e(Auth::user()->name); ?></strong></br>
<strong> Your Email: <?php echo e(Auth::user()->email); ?></strong></br>
<a href="<?php echo e(url('logout')); ?>" >Logout</a>
<?php else: ?>
<script>window.loation="/";</script>
<?php endif; ?>
</body>
    </body>
</html>
<?php /**PATH C:\Users\cscstaff\Downloads\HelloApp\resources\views/success.blade.php ENDPATH**/ ?>