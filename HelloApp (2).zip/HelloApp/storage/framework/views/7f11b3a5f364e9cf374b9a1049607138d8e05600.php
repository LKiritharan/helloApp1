<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
       <title>La</title>
</head>
<body> 
<h1>Welcome page</h1>

</body>
    </body>
</html>
<?php /**PATH C:\Users\cscstaff\Downloads\HelloApp\resources\views/welcome.blade.php ENDPATH**/ ?>