<!DOCTYPE html>
<html >
    <head>
       <title>La</title>
</head>
<body> 
<h1>index page</h1>

</body>
    </body>
</html>
<?php /**PATH C:\Users\cscstaff\Downloads\HelloApp\resources\views/index.blade.php ENDPATH**/ ?>